﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Public Class VenderReview
    Inherits DevExpress.XtraReports.UI.XtraReport

    'XtraReport overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Designer
    'It can be modified using the Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VenderReview))
        Me.TopMargin = New DevExpress.XtraReports.UI.TopMarginBand()
        Me.BottomMargin = New DevExpress.XtraReports.UI.BottomMarginBand()
        Me.ReportHeader = New DevExpress.XtraReports.UI.ReportHeaderBand()
        Me.XrTable4 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow37 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell147 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell148 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell151 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow38 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell152 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell153 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell154 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTable3 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow11 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell21 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell22 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell24 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell25 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell23 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow12 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell26 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell27 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell28 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell29 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell30 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow13 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell31 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell32 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell33 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell34 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell35 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow14 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell36 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell37 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell38 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell39 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell40 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow15 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell41 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell42 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell43 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell44 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell45 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow16 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell46 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell47 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell48 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell49 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell50 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow17 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell51 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell52 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell53 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell54 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell55 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow18 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell56 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell57 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell58 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell59 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell60 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow19 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell61 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell62 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell63 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell64 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell65 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow20 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell66 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell67 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell68 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell69 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell70 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow21 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell71 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell72 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell73 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell74 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell75 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow22 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell76 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell77 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell78 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell79 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell80 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow23 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell81 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell82 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell83 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell84 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell85 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow24 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell86 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell87 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell88 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell89 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell90 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow25 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell91 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell92 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell93 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell94 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell95 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow26 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell96 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell97 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell98 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell99 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell100 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow27 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell101 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell102 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell103 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell104 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell105 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow28 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell106 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell107 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell108 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell109 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell110 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow29 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell111 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell112 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell113 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell114 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell115 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow30 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell116 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell117 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell118 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell119 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell120 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow31 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell121 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell122 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell123 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell124 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell125 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow32 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell126 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell127 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell128 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell129 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell130 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow33 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell131 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell132 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell133 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell134 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell135 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow34 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell136 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell137 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell138 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell139 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell140 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow35 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell141 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell142 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell143 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell144 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell145 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow36 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell146 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell149 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell150 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTable2 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow10 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell19 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell20 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTable1 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow1 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell1 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell2 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow2 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell4 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell5 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow3 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell7 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell8 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow4 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell3 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell6 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow5 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell9 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell10 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow6 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell11 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell12 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow7 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell13 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell14 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow8 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell15 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell16 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow9 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell17 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell18 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrLabel6 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel5 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel4 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel3 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel2 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel1 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrPictureBox1 = New DevExpress.XtraReports.UI.XRPictureBox()
        Me.ReportFooter = New DevExpress.XtraReports.UI.ReportFooterBand()
        Me.XrTable5 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow39 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell155 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell156 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell157 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell158 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow40 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell159 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell160 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow41 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell163 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell164 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow42 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell167 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell168 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow43 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell161 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow44 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell162 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow46 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell171 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableRow45 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell165 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell166 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell169 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell170 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.Detail = New DevExpress.XtraReports.UI.DetailBand()
        Me.XrTable6 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow47 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell172 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell173 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell174 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell175 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrPageInfo1 = New DevExpress.XtraReports.UI.XRPageInfo()
        Me.XrTable7 = New DevExpress.XtraReports.UI.XRTable()
        Me.XrTableRow48 = New DevExpress.XtraReports.UI.XRTableRow()
        Me.XrTableCell176 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell177 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell178 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell179 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrRichText1 = New DevExpress.XtraReports.UI.XRRichText()
        Me.XrTableCell180 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrTableCell181 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrRichText2 = New DevExpress.XtraReports.UI.XRRichText()
        Me.XrTableCell182 = New DevExpress.XtraReports.UI.XRTableCell()
        Me.XrRichText3 = New DevExpress.XtraReports.UI.XRRichText()
        CType(Me.XrTable4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrTable7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrRichText1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrRichText2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.XrRichText3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'TopMargin
        '
        Me.TopMargin.HeightF = 10.0!
        Me.TopMargin.Name = "TopMargin"
        '
        'BottomMargin
        '
        Me.BottomMargin.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrTable6})
        Me.BottomMargin.HeightF = 43.12541!
        Me.BottomMargin.Name = "BottomMargin"
        '
        'ReportHeader
        '
        Me.ReportHeader.Borders = CType((((DevExpress.XtraPrinting.BorderSide.Left Or DevExpress.XtraPrinting.BorderSide.Top) _
            Or DevExpress.XtraPrinting.BorderSide.Right) _
            Or DevExpress.XtraPrinting.BorderSide.Bottom), DevExpress.XtraPrinting.BorderSide)
        Me.ReportHeader.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrTable4, Me.XrTable3, Me.XrTable2, Me.XrTable1, Me.XrLabel6, Me.XrLabel5, Me.XrLabel4, Me.XrLabel3, Me.XrLabel2, Me.XrLabel1, Me.XrPictureBox1})
        Me.ReportHeader.HeightF = 960.0!
        Me.ReportHeader.Name = "ReportHeader"
        Me.ReportHeader.StylePriority.UseBorders = False
        '
        'XrTable4
        '
        Me.XrTable4.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTable4.LocationFloat = New DevExpress.Utils.PointFloat(10.0!, 910.0!)
        Me.XrTable4.Name = "XrTable4"
        Me.XrTable4.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable4.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow37, Me.XrTableRow38})
        Me.XrTable4.SizeF = New System.Drawing.SizeF(779.9999!, 50.0!)
        Me.XrTable4.StylePriority.UseFont = False
        Me.XrTable4.StylePriority.UseTextAlignment = False
        Me.XrTable4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrTableRow37
        '
        Me.XrTableRow37.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell147, Me.XrTableCell148, Me.XrTableCell151})
        Me.XrTableRow37.Name = "XrTableRow37"
        Me.XrTableRow37.Weight = 1.0R
        '
        'XrTableCell147
        '
        Me.XrTableCell147.Multiline = True
        Me.XrTableCell147.Name = "XrTableCell147"
        Me.XrTableCell147.StylePriority.UseTextAlignment = False
        Me.XrTableCell147.Text = "1"
        Me.XrTableCell147.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell147.Weight = 0.56249984741210934R
        '
        'XrTableCell148
        '
        Me.XrTableCell148.Multiline = True
        Me.XrTableCell148.Name = "XrTableCell148"
        Me.XrTableCell148.Text = "Ngưỡng chấp nhận:/ Accept condition"
        Me.XrTableCell148.Weight = 1.2499999237060548R
        '
        'XrTableCell151
        '
        Me.XrTableCell151.Multiline = True
        Me.XrTableCell151.Name = "XrTableCell151"
        Me.XrTableCell151.Text = "Đạt 12 điểm trở lên và các tiêu chí Q & D phải đạt từ 3 điểm trở lên/ Gain 12 mar" &
    "ks up and criterial Q & D must gain 3 marks up"
        Me.XrTableCell151.Weight = 5.9874990081787107R
        '
        'XrTableRow38
        '
        Me.XrTableRow38.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell152, Me.XrTableCell153, Me.XrTableCell154})
        Me.XrTableRow38.Name = "XrTableRow38"
        Me.XrTableRow38.Weight = 1.0R
        '
        'XrTableCell152
        '
        Me.XrTableCell152.Multiline = True
        Me.XrTableCell152.Name = "XrTableCell152"
        Me.XrTableCell152.StylePriority.UseTextAlignment = False
        Me.XrTableCell152.Text = "2"
        Me.XrTableCell152.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell152.Weight = 0.56249984741210934R
        '
        'XrTableCell153
        '
        Me.XrTableCell153.Multiline = True
        Me.XrTableCell153.Name = "XrTableCell153"
        Me.XrTableCell153.Text = "Không chấp nhận/ Not accept"
        Me.XrTableCell153.Weight = 1.2499999237060548R
        '
        'XrTableCell154
        '
        Me.XrTableCell154.Multiline = True
        Me.XrTableCell154.Name = "XrTableCell154"
        Me.XrTableCell154.Text = "Dưới 12 điểm hoặc đạt 12 điểm nhưng có một tiêu chí Q hoặc D bị điểm 2/ Below 12 " &
    "marks or gain 12 marks but has criteria Q or D gain 2 marks"
        Me.XrTableCell154.Weight = 5.9874990081787107R
        '
        'XrTable3
        '
        Me.XrTable3.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTable3.LocationFloat = New DevExpress.Utils.PointFloat(10.0!, 313.0!)
        Me.XrTable3.Name = "XrTable3"
        Me.XrTable3.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable3.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow11, Me.XrTableRow12, Me.XrTableRow13, Me.XrTableRow14, Me.XrTableRow15, Me.XrTableRow16, Me.XrTableRow17, Me.XrTableRow18, Me.XrTableRow19, Me.XrTableRow20, Me.XrTableRow21, Me.XrTableRow22, Me.XrTableRow23, Me.XrTableRow24, Me.XrTableRow25, Me.XrTableRow26, Me.XrTableRow27, Me.XrTableRow28, Me.XrTableRow29, Me.XrTableRow30, Me.XrTableRow31, Me.XrTableRow32, Me.XrTableRow33, Me.XrTableRow34, Me.XrTableRow35, Me.XrTableRow36})
        Me.XrTable3.SizeF = New System.Drawing.SizeF(779.9999!, 591.9642!)
        Me.XrTable3.StylePriority.UseFont = False
        '
        'XrTableRow11
        '
        Me.XrTableRow11.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell21, Me.XrTableCell22, Me.XrTableCell24, Me.XrTableCell25, Me.XrTableCell23})
        Me.XrTableRow11.Name = "XrTableRow11"
        Me.XrTableRow11.Weight = 0.4426230216801712R
        '
        'XrTableCell21
        '
        Me.XrTableCell21.Multiline = True
        Me.XrTableCell21.Name = "XrTableCell21"
        Me.XrTableCell21.StylePriority.UseTextAlignment = False
        Me.XrTableCell21.Text = "Hạn mục Item"
        Me.XrTableCell21.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell21.Weight = 0.35156240463256833R
        '
        'XrTableCell22
        '
        Me.XrTableCell22.Multiline = True
        Me.XrTableCell22.Name = "XrTableCell22"
        Me.XrTableCell22.StylePriority.UseTextAlignment = False
        Me.XrTableCell22.Text = "STT/No"
        Me.XrTableCell22.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell22.Weight = 0.25000001827946372R
        '
        'XrTableCell24
        '
        Me.XrTableCell24.Multiline = True
        Me.XrTableCell24.Name = "XrTableCell24"
        Me.XrTableCell24.StylePriority.UseTextAlignment = False
        Me.XrTableCell24.Text = "Tiêu chí / Criteria"
        Me.XrTableCell24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell24.Weight = 3.2408851547723208R
        '
        'XrTableCell25
        '
        Me.XrTableCell25.Multiline = True
        Me.XrTableCell25.Name = "XrTableCell25"
        Me.XrTableCell25.StylePriority.UseTextAlignment = False
        Me.XrTableCell25.Text = "Điểm chuẩn" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Standard score"
        Me.XrTableCell25.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell25.Weight = 0.48567737972632735R
        '
        'XrTableCell23
        '
        Me.XrTableCell23.Multiline = True
        Me.XrTableCell23.Name = "XrTableCell23"
        Me.XrTableCell23.StylePriority.UseTextAlignment = False
        Me.XrTableCell23.Text = "Điểm đánh giá" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Evaluated score"
        Me.XrTableCell23.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell23.Weight = 0.54687461343587851R
        '
        'XrTableRow12
        '
        Me.XrTableRow12.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell26, Me.XrTableCell27, Me.XrTableCell28, Me.XrTableCell29, Me.XrTableCell30})
        Me.XrTableRow12.Name = "XrTableRow12"
        Me.XrTableRow12.Weight = 0.4426230216801712R
        '
        'XrTableCell26
        '
        Me.XrTableCell26.Multiline = True
        Me.XrTableCell26.Name = "XrTableCell26"
        Me.XrTableCell26.RowSpan = 6
        Me.XrTableCell26.StylePriority.UseTextAlignment = False
        Me.XrTableCell26.Text = "Q"
        Me.XrTableCell26.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell26.Weight = 0.35156240463256833R
        '
        'XrTableCell27
        '
        Me.XrTableCell27.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell27.Multiline = True
        Me.XrTableCell27.Name = "XrTableCell27"
        Me.XrTableCell27.StylePriority.UseFont = False
        Me.XrTableCell27.StylePriority.UseTextAlignment = False
        Me.XrTableCell27.Text = "1"
        Me.XrTableCell27.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell27.Weight = 0.25000001827946372R
        '
        'XrTableCell28
        '
        Me.XrTableCell28.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell28.Multiline = True
        Me.XrTableCell28.Name = "XrTableCell28"
        Me.XrTableCell28.StylePriority.UseFont = False
        Me.XrTableCell28.StylePriority.UseTextAlignment = False
        Me.XrTableCell28.Text = "Chất lượng sản phẩm  hoặc dịch vụ/ Product quanlity or Service quality"
        Me.XrTableCell28.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell28.Weight = 3.2408851547723208R
        '
        'XrTableCell29
        '
        Me.XrTableCell29.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell29.Multiline = True
        Me.XrTableCell29.Name = "XrTableCell29"
        Me.XrTableCell29.StylePriority.UseFont = False
        Me.XrTableCell29.StylePriority.UseTextAlignment = False
        Me.XrTableCell29.Text = "5"
        Me.XrTableCell29.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell29.Weight = 0.48567737972632735R
        '
        'XrTableCell30
        '
        Me.XrTableCell30.Multiline = True
        Me.XrTableCell30.Name = "XrTableCell30"
        Me.XrTableCell30.StylePriority.UseTextAlignment = False
        Me.XrTableCell30.Text = "para"
        Me.XrTableCell30.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell30.Weight = 0.54687461343587851R
        '
        'XrTableRow13
        '
        Me.XrTableRow13.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell31, Me.XrTableCell32, Me.XrTableCell33, Me.XrTableCell34, Me.XrTableCell35})
        Me.XrTableRow13.Name = "XrTableRow13"
        Me.XrTableRow13.Weight = 0.4426230216801712R
        '
        'XrTableCell31
        '
        Me.XrTableCell31.Multiline = True
        Me.XrTableCell31.Name = "XrTableCell31"
        Me.XrTableCell31.StylePriority.UseTextAlignment = False
        Me.XrTableCell31.Text = "XrTableCell31"
        Me.XrTableCell31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell31.Weight = 0.35156240463256833R
        '
        'XrTableCell32
        '
        Me.XrTableCell32.Multiline = True
        Me.XrTableCell32.Name = "XrTableCell32"
        Me.XrTableCell32.StylePriority.UseTextAlignment = False
        Me.XrTableCell32.Text = "1.1"
        Me.XrTableCell32.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell32.Weight = 0.25000001827946372R
        '
        'XrTableCell33
        '
        Me.XrTableCell33.Multiline = True
        Me.XrTableCell33.Name = "XrTableCell33"
        Me.XrTableCell33.StylePriority.UseTextAlignment = False
        Me.XrTableCell33.Text = "Số lượng lỗi trong kỳ đánh giá 0~ dưới 1% %/ Non conformity of quality 0% ~ below" &
    " 1%"
        Me.XrTableCell33.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell33.Weight = 3.2408851547723208R
        '
        'XrTableCell34
        '
        Me.XrTableCell34.Multiline = True
        Me.XrTableCell34.Name = "XrTableCell34"
        Me.XrTableCell34.StylePriority.UseTextAlignment = False
        Me.XrTableCell34.Text = "5"
        Me.XrTableCell34.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell34.Weight = 0.48567737972632735R
        '
        'XrTableCell35
        '
        Me.XrTableCell35.Multiline = True
        Me.XrTableCell35.Name = "XrTableCell35"
        Me.XrTableCell35.StylePriority.UseTextAlignment = False
        Me.XrTableCell35.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell35.Weight = 0.54687461343587851R
        '
        'XrTableRow14
        '
        Me.XrTableRow14.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell36, Me.XrTableCell37, Me.XrTableCell38, Me.XrTableCell39, Me.XrTableCell40})
        Me.XrTableRow14.Name = "XrTableRow14"
        Me.XrTableRow14.Weight = 0.4426230216801712R
        '
        'XrTableCell36
        '
        Me.XrTableCell36.Multiline = True
        Me.XrTableCell36.Name = "XrTableCell36"
        Me.XrTableCell36.StylePriority.UseTextAlignment = False
        Me.XrTableCell36.Text = "XrTableCell36"
        Me.XrTableCell36.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell36.Weight = 0.35156240463256833R
        '
        'XrTableCell37
        '
        Me.XrTableCell37.Multiline = True
        Me.XrTableCell37.Name = "XrTableCell37"
        Me.XrTableCell37.StylePriority.UseTextAlignment = False
        Me.XrTableCell37.Text = "1.2"
        Me.XrTableCell37.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell37.Weight = 0.25000001827946372R
        '
        'XrTableCell38
        '
        Me.XrTableCell38.Multiline = True
        Me.XrTableCell38.Name = "XrTableCell38"
        Me.XrTableCell38.StylePriority.UseTextAlignment = False
        Me.XrTableCell38.Text = "Số lượng lỗi trong kỳ đánh giá từ 1% ~ 5%/ Non conformity of quality from 1% ~ 5 " &
    "%"
        Me.XrTableCell38.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell38.Weight = 3.2408851547723208R
        '
        'XrTableCell39
        '
        Me.XrTableCell39.Multiline = True
        Me.XrTableCell39.Name = "XrTableCell39"
        Me.XrTableCell39.StylePriority.UseTextAlignment = False
        Me.XrTableCell39.Text = "4"
        Me.XrTableCell39.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell39.Weight = 0.48567737972632735R
        '
        'XrTableCell40
        '
        Me.XrTableCell40.Multiline = True
        Me.XrTableCell40.Name = "XrTableCell40"
        Me.XrTableCell40.StylePriority.UseTextAlignment = False
        Me.XrTableCell40.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell40.Weight = 0.54687461343587851R
        '
        'XrTableRow15
        '
        Me.XrTableRow15.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell41, Me.XrTableCell42, Me.XrTableCell43, Me.XrTableCell44, Me.XrTableCell45})
        Me.XrTableRow15.Name = "XrTableRow15"
        Me.XrTableRow15.Weight = 0.4426230216801712R
        '
        'XrTableCell41
        '
        Me.XrTableCell41.Multiline = True
        Me.XrTableCell41.Name = "XrTableCell41"
        Me.XrTableCell41.StylePriority.UseTextAlignment = False
        Me.XrTableCell41.Text = "XrTableCell41"
        Me.XrTableCell41.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell41.Weight = 0.35156240463256833R
        '
        'XrTableCell42
        '
        Me.XrTableCell42.Multiline = True
        Me.XrTableCell42.Name = "XrTableCell42"
        Me.XrTableCell42.StylePriority.UseTextAlignment = False
        Me.XrTableCell42.Text = "1.3"
        Me.XrTableCell42.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell42.Weight = 0.25000001827946372R
        '
        'XrTableCell43
        '
        Me.XrTableCell43.Multiline = True
        Me.XrTableCell43.Name = "XrTableCell43"
        Me.XrTableCell43.StylePriority.UseTextAlignment = False
        Me.XrTableCell43.Text = "Số lượng lỗi trong kỳ đánh giá từ 6% ~ 10%/ Non conformity of quality from 6% ~ 1" &
    "0 %"
        Me.XrTableCell43.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell43.Weight = 3.2408851547723208R
        '
        'XrTableCell44
        '
        Me.XrTableCell44.Multiline = True
        Me.XrTableCell44.Name = "XrTableCell44"
        Me.XrTableCell44.StylePriority.UseTextAlignment = False
        Me.XrTableCell44.Text = "3"
        Me.XrTableCell44.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell44.Weight = 0.48567737972632735R
        '
        'XrTableCell45
        '
        Me.XrTableCell45.Multiline = True
        Me.XrTableCell45.Name = "XrTableCell45"
        Me.XrTableCell45.StylePriority.UseTextAlignment = False
        Me.XrTableCell45.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell45.Weight = 0.54687461343587851R
        '
        'XrTableRow16
        '
        Me.XrTableRow16.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell46, Me.XrTableCell47, Me.XrTableCell48, Me.XrTableCell49, Me.XrTableCell50})
        Me.XrTableRow16.Name = "XrTableRow16"
        Me.XrTableRow16.Weight = 0.4426230216801712R
        '
        'XrTableCell46
        '
        Me.XrTableCell46.Multiline = True
        Me.XrTableCell46.Name = "XrTableCell46"
        Me.XrTableCell46.StylePriority.UseTextAlignment = False
        Me.XrTableCell46.Text = "XrTableCell46"
        Me.XrTableCell46.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell46.Weight = 0.35156240463256833R
        '
        'XrTableCell47
        '
        Me.XrTableCell47.Multiline = True
        Me.XrTableCell47.Name = "XrTableCell47"
        Me.XrTableCell47.StylePriority.UseTextAlignment = False
        Me.XrTableCell47.Text = "1.4"
        Me.XrTableCell47.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell47.Weight = 0.25000001827946372R
        '
        'XrTableCell48
        '
        Me.XrTableCell48.Multiline = True
        Me.XrTableCell48.Name = "XrTableCell48"
        Me.XrTableCell48.StylePriority.UseTextAlignment = False
        Me.XrTableCell48.Text = "Số lượng lỗi trong kỳ đánh giá từ 11% ~ 15%/ Non conformity of quality from 11% ~" &
    " 15%"
        Me.XrTableCell48.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell48.Weight = 3.2408851547723208R
        '
        'XrTableCell49
        '
        Me.XrTableCell49.Multiline = True
        Me.XrTableCell49.Name = "XrTableCell49"
        Me.XrTableCell49.StylePriority.UseTextAlignment = False
        Me.XrTableCell49.Text = "2"
        Me.XrTableCell49.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell49.Weight = 0.48567737972632735R
        '
        'XrTableCell50
        '
        Me.XrTableCell50.Multiline = True
        Me.XrTableCell50.Name = "XrTableCell50"
        Me.XrTableCell50.StylePriority.UseTextAlignment = False
        Me.XrTableCell50.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell50.Weight = 0.54687461343587851R
        '
        'XrTableRow17
        '
        Me.XrTableRow17.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell51, Me.XrTableCell52, Me.XrTableCell53, Me.XrTableCell54, Me.XrTableCell55})
        Me.XrTableRow17.Name = "XrTableRow17"
        Me.XrTableRow17.Weight = 0.4426230216801712R
        '
        'XrTableCell51
        '
        Me.XrTableCell51.Multiline = True
        Me.XrTableCell51.Name = "XrTableCell51"
        Me.XrTableCell51.StylePriority.UseTextAlignment = False
        Me.XrTableCell51.Text = "XrTableCell51"
        Me.XrTableCell51.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell51.Weight = 0.35156240463256833R
        '
        'XrTableCell52
        '
        Me.XrTableCell52.Multiline = True
        Me.XrTableCell52.Name = "XrTableCell52"
        Me.XrTableCell52.StylePriority.UseTextAlignment = False
        Me.XrTableCell52.Text = "1.5"
        Me.XrTableCell52.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell52.Weight = 0.25000001827946372R
        '
        'XrTableCell53
        '
        Me.XrTableCell53.Multiline = True
        Me.XrTableCell53.Name = "XrTableCell53"
        Me.XrTableCell53.StylePriority.UseTextAlignment = False
        Me.XrTableCell53.Text = "Số lượng lỗi trong kỳ đánh giá từ 16% trở lên/ Non conformity of quality from 16%" &
    " up"
        Me.XrTableCell53.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell53.Weight = 3.2408851547723208R
        '
        'XrTableCell54
        '
        Me.XrTableCell54.Multiline = True
        Me.XrTableCell54.Name = "XrTableCell54"
        Me.XrTableCell54.StylePriority.UseTextAlignment = False
        Me.XrTableCell54.Text = "1"
        Me.XrTableCell54.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell54.Weight = 0.48567737972632735R
        '
        'XrTableCell55
        '
        Me.XrTableCell55.Multiline = True
        Me.XrTableCell55.Name = "XrTableCell55"
        Me.XrTableCell55.StylePriority.UseTextAlignment = False
        Me.XrTableCell55.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell55.Weight = 0.54687461343587851R
        '
        'XrTableRow18
        '
        Me.XrTableRow18.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell56, Me.XrTableCell57, Me.XrTableCell58, Me.XrTableCell59, Me.XrTableCell60})
        Me.XrTableRow18.Name = "XrTableRow18"
        Me.XrTableRow18.Weight = 0.4426230216801712R
        '
        'XrTableCell56
        '
        Me.XrTableCell56.Multiline = True
        Me.XrTableCell56.Name = "XrTableCell56"
        Me.XrTableCell56.RowSpan = 6
        Me.XrTableCell56.StylePriority.UseTextAlignment = False
        Me.XrTableCell56.Text = "R"
        Me.XrTableCell56.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell56.Weight = 0.35156240463256833R
        '
        'XrTableCell57
        '
        Me.XrTableCell57.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell57.Multiline = True
        Me.XrTableCell57.Name = "XrTableCell57"
        Me.XrTableCell57.StylePriority.UseFont = False
        Me.XrTableCell57.StylePriority.UseTextAlignment = False
        Me.XrTableCell57.Text = "2"
        Me.XrTableCell57.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell57.Weight = 0.25000001827946372R
        '
        'XrTableCell58
        '
        Me.XrTableCell58.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell58.Multiline = True
        Me.XrTableCell58.Name = "XrTableCell58"
        Me.XrTableCell58.StylePriority.UseFont = False
        Me.XrTableCell58.StylePriority.UseTextAlignment = False
        Me.XrTableCell58.Text = "Phản hồi khách hàng/ Customer respond  (tính trung bình của từng đơn hàng./ evara" &
    "ge core of line items)"
        Me.XrTableCell58.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell58.Weight = 3.2408851547723208R
        '
        'XrTableCell59
        '
        Me.XrTableCell59.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell59.Multiline = True
        Me.XrTableCell59.Name = "XrTableCell59"
        Me.XrTableCell59.StylePriority.UseFont = False
        Me.XrTableCell59.StylePriority.UseTextAlignment = False
        Me.XrTableCell59.Text = "5"
        Me.XrTableCell59.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell59.Weight = 0.48567737972632735R
        '
        'XrTableCell60
        '
        Me.XrTableCell60.Multiline = True
        Me.XrTableCell60.Name = "XrTableCell60"
        Me.XrTableCell60.StylePriority.UseTextAlignment = False
        Me.XrTableCell60.Text = "para"
        Me.XrTableCell60.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell60.Weight = 0.54687461343587851R
        '
        'XrTableRow19
        '
        Me.XrTableRow19.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell61, Me.XrTableCell62, Me.XrTableCell63, Me.XrTableCell64, Me.XrTableCell65})
        Me.XrTableRow19.Name = "XrTableRow19"
        Me.XrTableRow19.Weight = 0.4426230216801712R
        '
        'XrTableCell61
        '
        Me.XrTableCell61.Multiline = True
        Me.XrTableCell61.Name = "XrTableCell61"
        Me.XrTableCell61.StylePriority.UseTextAlignment = False
        Me.XrTableCell61.Text = "XrTableCell61"
        Me.XrTableCell61.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell61.Weight = 0.35156240463256833R
        '
        'XrTableCell62
        '
        Me.XrTableCell62.Multiline = True
        Me.XrTableCell62.Name = "XrTableCell62"
        Me.XrTableCell62.StylePriority.UseTextAlignment = False
        Me.XrTableCell62.Text = "2.1"
        Me.XrTableCell62.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell62.Weight = 0.25000001827946372R
        '
        'XrTableCell63
        '
        Me.XrTableCell63.Multiline = True
        Me.XrTableCell63.Name = "XrTableCell63"
        Me.XrTableCell63.StylePriority.UseTextAlignment = False
        Me.XrTableCell63.Text = "Đáp ứng yêu cầu, phản hồi và khăc phục sự cố trong 1 ngày làm việc/ Meet requirem" &
    "ent, respons and corrective action within 1 working day "
        Me.XrTableCell63.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell63.Weight = 3.2408851547723208R
        '
        'XrTableCell64
        '
        Me.XrTableCell64.Multiline = True
        Me.XrTableCell64.Name = "XrTableCell64"
        Me.XrTableCell64.StylePriority.UseTextAlignment = False
        Me.XrTableCell64.Text = "5"
        Me.XrTableCell64.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell64.Weight = 0.48567737972632735R
        '
        'XrTableCell65
        '
        Me.XrTableCell65.Multiline = True
        Me.XrTableCell65.Name = "XrTableCell65"
        Me.XrTableCell65.StylePriority.UseTextAlignment = False
        Me.XrTableCell65.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell65.Weight = 0.54687461343587851R
        '
        'XrTableRow20
        '
        Me.XrTableRow20.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell66, Me.XrTableCell67, Me.XrTableCell68, Me.XrTableCell69, Me.XrTableCell70})
        Me.XrTableRow20.Name = "XrTableRow20"
        Me.XrTableRow20.Weight = 0.4426230216801712R
        '
        'XrTableCell66
        '
        Me.XrTableCell66.Multiline = True
        Me.XrTableCell66.Name = "XrTableCell66"
        Me.XrTableCell66.StylePriority.UseTextAlignment = False
        Me.XrTableCell66.Text = "XrTableCell66"
        Me.XrTableCell66.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell66.Weight = 0.35156240463256833R
        '
        'XrTableCell67
        '
        Me.XrTableCell67.Multiline = True
        Me.XrTableCell67.Name = "XrTableCell67"
        Me.XrTableCell67.StylePriority.UseTextAlignment = False
        Me.XrTableCell67.Text = "2.2"
        Me.XrTableCell67.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell67.Weight = 0.25000001827946372R
        '
        'XrTableCell68
        '
        Me.XrTableCell68.Multiline = True
        Me.XrTableCell68.Name = "XrTableCell68"
        Me.XrTableCell68.StylePriority.UseTextAlignment = False
        Me.XrTableCell68.Text = "Đáp ứng yêu cầu, phản hồi và khăc phục sự cố trong 2 ngày làm việc/ Meet requirem" &
    "ent, respons and corrective action within 2 working days "
        Me.XrTableCell68.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell68.Weight = 3.2408851547723208R
        '
        'XrTableCell69
        '
        Me.XrTableCell69.Multiline = True
        Me.XrTableCell69.Name = "XrTableCell69"
        Me.XrTableCell69.StylePriority.UseTextAlignment = False
        Me.XrTableCell69.Text = "4"
        Me.XrTableCell69.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell69.Weight = 0.48567737972632735R
        '
        'XrTableCell70
        '
        Me.XrTableCell70.Multiline = True
        Me.XrTableCell70.Name = "XrTableCell70"
        Me.XrTableCell70.StylePriority.UseTextAlignment = False
        Me.XrTableCell70.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell70.Weight = 0.54687461343587851R
        '
        'XrTableRow21
        '
        Me.XrTableRow21.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell71, Me.XrTableCell72, Me.XrTableCell73, Me.XrTableCell74, Me.XrTableCell75})
        Me.XrTableRow21.Name = "XrTableRow21"
        Me.XrTableRow21.Weight = 0.4426230216801712R
        '
        'XrTableCell71
        '
        Me.XrTableCell71.Multiline = True
        Me.XrTableCell71.Name = "XrTableCell71"
        Me.XrTableCell71.StylePriority.UseTextAlignment = False
        Me.XrTableCell71.Text = "XrTableCell71"
        Me.XrTableCell71.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell71.Weight = 0.35156240463256833R
        '
        'XrTableCell72
        '
        Me.XrTableCell72.Multiline = True
        Me.XrTableCell72.Name = "XrTableCell72"
        Me.XrTableCell72.StylePriority.UseTextAlignment = False
        Me.XrTableCell72.Text = "2.3"
        Me.XrTableCell72.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell72.Weight = 0.25000001827946372R
        '
        'XrTableCell73
        '
        Me.XrTableCell73.Multiline = True
        Me.XrTableCell73.Name = "XrTableCell73"
        Me.XrTableCell73.StylePriority.UseTextAlignment = False
        Me.XrTableCell73.Text = "Đáp ứng yêu cầu, phản hồi và khăc phục sự cố sau 3 ngày làm việc/ Meet requiremen" &
    "t, respons and corrective action after 3 working days "
        Me.XrTableCell73.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell73.Weight = 3.2408851547723208R
        '
        'XrTableCell74
        '
        Me.XrTableCell74.Multiline = True
        Me.XrTableCell74.Name = "XrTableCell74"
        Me.XrTableCell74.StylePriority.UseTextAlignment = False
        Me.XrTableCell74.Text = "3"
        Me.XrTableCell74.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell74.Weight = 0.48567737972632735R
        '
        'XrTableCell75
        '
        Me.XrTableCell75.Multiline = True
        Me.XrTableCell75.Name = "XrTableCell75"
        Me.XrTableCell75.StylePriority.UseTextAlignment = False
        Me.XrTableCell75.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell75.Weight = 0.54687461343587851R
        '
        'XrTableRow22
        '
        Me.XrTableRow22.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell76, Me.XrTableCell77, Me.XrTableCell78, Me.XrTableCell79, Me.XrTableCell80})
        Me.XrTableRow22.Name = "XrTableRow22"
        Me.XrTableRow22.Weight = 0.4426230216801712R
        '
        'XrTableCell76
        '
        Me.XrTableCell76.Multiline = True
        Me.XrTableCell76.Name = "XrTableCell76"
        Me.XrTableCell76.StylePriority.UseTextAlignment = False
        Me.XrTableCell76.Text = "XrTableCell76"
        Me.XrTableCell76.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell76.Weight = 0.35156240463256833R
        '
        'XrTableCell77
        '
        Me.XrTableCell77.Multiline = True
        Me.XrTableCell77.Name = "XrTableCell77"
        Me.XrTableCell77.StylePriority.UseTextAlignment = False
        Me.XrTableCell77.Text = "2.4"
        Me.XrTableCell77.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell77.Weight = 0.25000001827946372R
        '
        'XrTableCell78
        '
        Me.XrTableCell78.Multiline = True
        Me.XrTableCell78.Name = "XrTableCell78"
        Me.XrTableCell78.StylePriority.UseTextAlignment = False
        Me.XrTableCell78.Text = "Đáp ứng yêu cầu, phản hồi và khăc phục sự cố sau 4 ngày làm việc/ Meet requiremen" &
    "t, respons and corrective action after 4 working days "
        Me.XrTableCell78.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell78.Weight = 3.2408851547723208R
        '
        'XrTableCell79
        '
        Me.XrTableCell79.Multiline = True
        Me.XrTableCell79.Name = "XrTableCell79"
        Me.XrTableCell79.StylePriority.UseTextAlignment = False
        Me.XrTableCell79.Text = "2"
        Me.XrTableCell79.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell79.Weight = 0.48567737972632735R
        '
        'XrTableCell80
        '
        Me.XrTableCell80.Multiline = True
        Me.XrTableCell80.Name = "XrTableCell80"
        Me.XrTableCell80.StylePriority.UseTextAlignment = False
        Me.XrTableCell80.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell80.Weight = 0.54687461343587851R
        '
        'XrTableRow23
        '
        Me.XrTableRow23.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell81, Me.XrTableCell82, Me.XrTableCell83, Me.XrTableCell84, Me.XrTableCell85})
        Me.XrTableRow23.Name = "XrTableRow23"
        Me.XrTableRow23.Weight = 0.4426230216801712R
        '
        'XrTableCell81
        '
        Me.XrTableCell81.Multiline = True
        Me.XrTableCell81.Name = "XrTableCell81"
        Me.XrTableCell81.StylePriority.UseTextAlignment = False
        Me.XrTableCell81.Text = "XrTableCell81"
        Me.XrTableCell81.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell81.Weight = 0.35156240463256833R
        '
        'XrTableCell82
        '
        Me.XrTableCell82.Multiline = True
        Me.XrTableCell82.Name = "XrTableCell82"
        Me.XrTableCell82.StylePriority.UseTextAlignment = False
        Me.XrTableCell82.Text = "2.5"
        Me.XrTableCell82.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell82.Weight = 0.25000001827946372R
        '
        'XrTableCell83
        '
        Me.XrTableCell83.Multiline = True
        Me.XrTableCell83.Name = "XrTableCell83"
        Me.XrTableCell83.StylePriority.UseTextAlignment = False
        Me.XrTableCell83.Text = "Đáp ứng yêu cầu, phản hồi và khăc phục sự cố sau 4 ngày làm việc trở lên/ Meet re" &
    "quirement, respons and corrective action after 4 working days up"
        Me.XrTableCell83.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell83.Weight = 3.2408851547723208R
        '
        'XrTableCell84
        '
        Me.XrTableCell84.Multiline = True
        Me.XrTableCell84.Name = "XrTableCell84"
        Me.XrTableCell84.StylePriority.UseTextAlignment = False
        Me.XrTableCell84.Text = "1"
        Me.XrTableCell84.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell84.Weight = 0.48567737972632735R
        '
        'XrTableCell85
        '
        Me.XrTableCell85.Multiline = True
        Me.XrTableCell85.Name = "XrTableCell85"
        Me.XrTableCell85.StylePriority.UseTextAlignment = False
        Me.XrTableCell85.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell85.Weight = 0.54687461343587851R
        '
        'XrTableRow24
        '
        Me.XrTableRow24.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell86, Me.XrTableCell87, Me.XrTableCell88, Me.XrTableCell89, Me.XrTableCell90})
        Me.XrTableRow24.Name = "XrTableRow24"
        Me.XrTableRow24.Weight = 0.4426230216801712R
        '
        'XrTableCell86
        '
        Me.XrTableCell86.Multiline = True
        Me.XrTableCell86.Name = "XrTableCell86"
        Me.XrTableCell86.RowSpan = 6
        Me.XrTableCell86.StylePriority.UseTextAlignment = False
        Me.XrTableCell86.Text = "C"
        Me.XrTableCell86.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell86.Weight = 0.35156240463256833R
        '
        'XrTableCell87
        '
        Me.XrTableCell87.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell87.Multiline = True
        Me.XrTableCell87.Name = "XrTableCell87"
        Me.XrTableCell87.StylePriority.UseFont = False
        Me.XrTableCell87.StylePriority.UseTextAlignment = False
        Me.XrTableCell87.Text = "3"
        Me.XrTableCell87.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell87.Weight = 0.25000001827946372R
        '
        'XrTableCell88
        '
        Me.XrTableCell88.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell88.Multiline = True
        Me.XrTableCell88.Name = "XrTableCell88"
        Me.XrTableCell88.StylePriority.UseFont = False
        Me.XrTableCell88.StylePriority.UseTextAlignment = False
        Me.XrTableCell88.Text = "Giá cả & điều kiện thanh toán/Price & Payment"
        Me.XrTableCell88.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell88.Weight = 3.2408851547723208R
        '
        'XrTableCell89
        '
        Me.XrTableCell89.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell89.Multiline = True
        Me.XrTableCell89.Name = "XrTableCell89"
        Me.XrTableCell89.StylePriority.UseFont = False
        Me.XrTableCell89.StylePriority.UseTextAlignment = False
        Me.XrTableCell89.Text = "5"
        Me.XrTableCell89.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell89.Weight = 0.48567737972632735R
        '
        'XrTableCell90
        '
        Me.XrTableCell90.Multiline = True
        Me.XrTableCell90.Name = "XrTableCell90"
        Me.XrTableCell90.StylePriority.UseTextAlignment = False
        Me.XrTableCell90.Text = "para"
        Me.XrTableCell90.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell90.Weight = 0.54687461343587851R
        '
        'XrTableRow25
        '
        Me.XrTableRow25.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell91, Me.XrTableCell92, Me.XrTableCell93, Me.XrTableCell94, Me.XrTableCell95})
        Me.XrTableRow25.Name = "XrTableRow25"
        Me.XrTableRow25.Weight = 0.4426230216801712R
        '
        'XrTableCell91
        '
        Me.XrTableCell91.Multiline = True
        Me.XrTableCell91.Name = "XrTableCell91"
        Me.XrTableCell91.StylePriority.UseTextAlignment = False
        Me.XrTableCell91.Text = "XrTableCell91"
        Me.XrTableCell91.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell91.Weight = 0.35156240463256833R
        '
        'XrTableCell92
        '
        Me.XrTableCell92.Multiline = True
        Me.XrTableCell92.Name = "XrTableCell92"
        Me.XrTableCell92.StylePriority.UseTextAlignment = False
        Me.XrTableCell92.Text = "3.1"
        Me.XrTableCell92.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell92.Weight = 0.25000001827946372R
        '
        'XrTableCell93
        '
        Me.XrTableCell93.Multiline = True
        Me.XrTableCell93.Name = "XrTableCell93"
        Me.XrTableCell93.StylePriority.UseTextAlignment = False
        Me.XrTableCell93.Text = "Giá thấp hơn giá thị trường / Price lower than market"
        Me.XrTableCell93.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell93.Weight = 3.2408851547723208R
        '
        'XrTableCell94
        '
        Me.XrTableCell94.Multiline = True
        Me.XrTableCell94.Name = "XrTableCell94"
        Me.XrTableCell94.StylePriority.UseTextAlignment = False
        Me.XrTableCell94.Text = "5"
        Me.XrTableCell94.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell94.Weight = 0.48567737972632735R
        '
        'XrTableCell95
        '
        Me.XrTableCell95.Multiline = True
        Me.XrTableCell95.Name = "XrTableCell95"
        Me.XrTableCell95.StylePriority.UseTextAlignment = False
        Me.XrTableCell95.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell95.Weight = 0.54687461343587851R
        '
        'XrTableRow26
        '
        Me.XrTableRow26.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell96, Me.XrTableCell97, Me.XrTableCell98, Me.XrTableCell99, Me.XrTableCell100})
        Me.XrTableRow26.Name = "XrTableRow26"
        Me.XrTableRow26.Weight = 0.4426230216801712R
        '
        'XrTableCell96
        '
        Me.XrTableCell96.Multiline = True
        Me.XrTableCell96.Name = "XrTableCell96"
        Me.XrTableCell96.StylePriority.UseTextAlignment = False
        Me.XrTableCell96.Text = "XrTableCell96"
        Me.XrTableCell96.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell96.Weight = 0.35156240463256833R
        '
        'XrTableCell97
        '
        Me.XrTableCell97.Multiline = True
        Me.XrTableCell97.Name = "XrTableCell97"
        Me.XrTableCell97.StylePriority.UseTextAlignment = False
        Me.XrTableCell97.Text = "3.2"
        Me.XrTableCell97.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell97.Weight = 0.25000001827946372R
        '
        'XrTableCell98
        '
        Me.XrTableCell98.Multiline = True
        Me.XrTableCell98.Name = "XrTableCell98"
        Me.XrTableCell98.StylePriority.UseTextAlignment = False
        Me.XrTableCell98.Text = "Giá ngang bằng giá thị trường / Price equal to Average market price"
        Me.XrTableCell98.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell98.Weight = 3.2408851547723208R
        '
        'XrTableCell99
        '
        Me.XrTableCell99.Multiline = True
        Me.XrTableCell99.Name = "XrTableCell99"
        Me.XrTableCell99.StylePriority.UseTextAlignment = False
        Me.XrTableCell99.Text = "4"
        Me.XrTableCell99.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell99.Weight = 0.48567737972632735R
        '
        'XrTableCell100
        '
        Me.XrTableCell100.Multiline = True
        Me.XrTableCell100.Name = "XrTableCell100"
        Me.XrTableCell100.StylePriority.UseTextAlignment = False
        Me.XrTableCell100.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell100.Weight = 0.54687461343587851R
        '
        'XrTableRow27
        '
        Me.XrTableRow27.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell101, Me.XrTableCell102, Me.XrTableCell103, Me.XrTableCell104, Me.XrTableCell105})
        Me.XrTableRow27.Name = "XrTableRow27"
        Me.XrTableRow27.Weight = 0.4426230216801712R
        '
        'XrTableCell101
        '
        Me.XrTableCell101.Multiline = True
        Me.XrTableCell101.Name = "XrTableCell101"
        Me.XrTableCell101.StylePriority.UseTextAlignment = False
        Me.XrTableCell101.Text = "XrTableCell101"
        Me.XrTableCell101.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell101.Weight = 0.35156240463256833R
        '
        'XrTableCell102
        '
        Me.XrTableCell102.Multiline = True
        Me.XrTableCell102.Name = "XrTableCell102"
        Me.XrTableCell102.StylePriority.UseTextAlignment = False
        Me.XrTableCell102.Text = "3.3"
        Me.XrTableCell102.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell102.Weight = 0.25000001827946372R
        '
        'XrTableCell103
        '
        Me.XrTableCell103.Multiline = True
        Me.XrTableCell103.Name = "XrTableCell103"
        Me.XrTableCell103.StylePriority.UseTextAlignment = False
        Me.XrTableCell103.Text = "Giá cao hơn thị trường và dưới 5 %/ Price higher than market & below 5%"
        Me.XrTableCell103.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell103.Weight = 3.2408851547723208R
        '
        'XrTableCell104
        '
        Me.XrTableCell104.Multiline = True
        Me.XrTableCell104.Name = "XrTableCell104"
        Me.XrTableCell104.StylePriority.UseTextAlignment = False
        Me.XrTableCell104.Text = "3"
        Me.XrTableCell104.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell104.Weight = 0.48567737972632735R
        '
        'XrTableCell105
        '
        Me.XrTableCell105.Multiline = True
        Me.XrTableCell105.Name = "XrTableCell105"
        Me.XrTableCell105.StylePriority.UseTextAlignment = False
        Me.XrTableCell105.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell105.Weight = 0.54687461343587851R
        '
        'XrTableRow28
        '
        Me.XrTableRow28.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell106, Me.XrTableCell107, Me.XrTableCell108, Me.XrTableCell109, Me.XrTableCell110})
        Me.XrTableRow28.Name = "XrTableRow28"
        Me.XrTableRow28.Weight = 0.4426230216801712R
        '
        'XrTableCell106
        '
        Me.XrTableCell106.Multiline = True
        Me.XrTableCell106.Name = "XrTableCell106"
        Me.XrTableCell106.StylePriority.UseTextAlignment = False
        Me.XrTableCell106.Text = "XrTableCell106"
        Me.XrTableCell106.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell106.Weight = 0.35156240463256833R
        '
        'XrTableCell107
        '
        Me.XrTableCell107.Multiline = True
        Me.XrTableCell107.Name = "XrTableCell107"
        Me.XrTableCell107.StylePriority.UseTextAlignment = False
        Me.XrTableCell107.Text = "3.4"
        Me.XrTableCell107.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell107.Weight = 0.25000001827946372R
        '
        'XrTableCell108
        '
        Me.XrTableCell108.Multiline = True
        Me.XrTableCell108.Name = "XrTableCell108"
        Me.XrTableCell108.StylePriority.UseTextAlignment = False
        Me.XrTableCell108.Text = "Giá cao hơn market 5 % ~ 10%/ Price higher than market 5% ~ 10%"
        Me.XrTableCell108.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell108.Weight = 3.2408851547723208R
        '
        'XrTableCell109
        '
        Me.XrTableCell109.Multiline = True
        Me.XrTableCell109.Name = "XrTableCell109"
        Me.XrTableCell109.StylePriority.UseTextAlignment = False
        Me.XrTableCell109.Text = "2"
        Me.XrTableCell109.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell109.Weight = 0.48567737972632735R
        '
        'XrTableCell110
        '
        Me.XrTableCell110.Multiline = True
        Me.XrTableCell110.Name = "XrTableCell110"
        Me.XrTableCell110.StylePriority.UseTextAlignment = False
        Me.XrTableCell110.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell110.Weight = 0.54687461343587851R
        '
        'XrTableRow29
        '
        Me.XrTableRow29.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell111, Me.XrTableCell112, Me.XrTableCell113, Me.XrTableCell114, Me.XrTableCell115})
        Me.XrTableRow29.Name = "XrTableRow29"
        Me.XrTableRow29.Weight = 0.4426230216801712R
        '
        'XrTableCell111
        '
        Me.XrTableCell111.Multiline = True
        Me.XrTableCell111.Name = "XrTableCell111"
        Me.XrTableCell111.StylePriority.UseTextAlignment = False
        Me.XrTableCell111.Text = "XrTableCell111"
        Me.XrTableCell111.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell111.Weight = 0.35156240463256833R
        '
        'XrTableCell112
        '
        Me.XrTableCell112.Multiline = True
        Me.XrTableCell112.Name = "XrTableCell112"
        Me.XrTableCell112.StylePriority.UseTextAlignment = False
        Me.XrTableCell112.Text = "3.5"
        Me.XrTableCell112.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell112.Weight = 0.25000001827946372R
        '
        'XrTableCell113
        '
        Me.XrTableCell113.Multiline = True
        Me.XrTableCell113.Name = "XrTableCell113"
        Me.XrTableCell113.StylePriority.UseTextAlignment = False
        Me.XrTableCell113.Text = "Giá cao hơn thị trường từ  11% trở lên / Price higher than market from 11% up"
        Me.XrTableCell113.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell113.Weight = 3.2408851547723208R
        '
        'XrTableCell114
        '
        Me.XrTableCell114.Multiline = True
        Me.XrTableCell114.Name = "XrTableCell114"
        Me.XrTableCell114.StylePriority.UseTextAlignment = False
        Me.XrTableCell114.Text = "1"
        Me.XrTableCell114.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell114.Weight = 0.48567737972632735R
        '
        'XrTableCell115
        '
        Me.XrTableCell115.Multiline = True
        Me.XrTableCell115.Name = "XrTableCell115"
        Me.XrTableCell115.StylePriority.UseTextAlignment = False
        Me.XrTableCell115.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell115.Weight = 0.54687461343587851R
        '
        'XrTableRow30
        '
        Me.XrTableRow30.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell116, Me.XrTableCell117, Me.XrTableCell118, Me.XrTableCell119, Me.XrTableCell120})
        Me.XrTableRow30.Name = "XrTableRow30"
        Me.XrTableRow30.Weight = 0.4426230216801712R
        '
        'XrTableCell116
        '
        Me.XrTableCell116.Multiline = True
        Me.XrTableCell116.Name = "XrTableCell116"
        Me.XrTableCell116.RowSpan = 6
        Me.XrTableCell116.StylePriority.UseTextAlignment = False
        Me.XrTableCell116.Text = "D"
        Me.XrTableCell116.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell116.Weight = 0.35156240463256833R
        '
        'XrTableCell117
        '
        Me.XrTableCell117.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell117.Multiline = True
        Me.XrTableCell117.Name = "XrTableCell117"
        Me.XrTableCell117.StylePriority.UseFont = False
        Me.XrTableCell117.StylePriority.UseTextAlignment = False
        Me.XrTableCell117.Text = "4"
        Me.XrTableCell117.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell117.Weight = 0.25000001827946372R
        '
        'XrTableCell118
        '
        Me.XrTableCell118.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell118.Multiline = True
        Me.XrTableCell118.Name = "XrTableCell118"
        Me.XrTableCell118.StylePriority.UseFont = False
        Me.XrTableCell118.StylePriority.UseTextAlignment = False
        Me.XrTableCell118.Text = "Thời gian giao hàng/Delivery"
        Me.XrTableCell118.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell118.Weight = 3.2408851547723208R
        '
        'XrTableCell119
        '
        Me.XrTableCell119.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell119.Multiline = True
        Me.XrTableCell119.Name = "XrTableCell119"
        Me.XrTableCell119.StylePriority.UseFont = False
        Me.XrTableCell119.StylePriority.UseTextAlignment = False
        Me.XrTableCell119.Text = "5"
        Me.XrTableCell119.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell119.Weight = 0.48567737972632735R
        '
        'XrTableCell120
        '
        Me.XrTableCell120.Multiline = True
        Me.XrTableCell120.Name = "XrTableCell120"
        Me.XrTableCell120.StylePriority.UseTextAlignment = False
        Me.XrTableCell120.Text = "para"
        Me.XrTableCell120.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell120.Weight = 0.54687461343587851R
        '
        'XrTableRow31
        '
        Me.XrTableRow31.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell121, Me.XrTableCell122, Me.XrTableCell123, Me.XrTableCell124, Me.XrTableCell125})
        Me.XrTableRow31.Name = "XrTableRow31"
        Me.XrTableRow31.Weight = 0.4426230216801712R
        '
        'XrTableCell121
        '
        Me.XrTableCell121.Multiline = True
        Me.XrTableCell121.Name = "XrTableCell121"
        Me.XrTableCell121.StylePriority.UseTextAlignment = False
        Me.XrTableCell121.Text = "XrTableCell121"
        Me.XrTableCell121.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell121.Weight = 0.35156240463256833R
        '
        'XrTableCell122
        '
        Me.XrTableCell122.Multiline = True
        Me.XrTableCell122.Name = "XrTableCell122"
        Me.XrTableCell122.StylePriority.UseTextAlignment = False
        Me.XrTableCell122.Text = "4.1"
        Me.XrTableCell122.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell122.Weight = 0.25000001827946372R
        '
        'XrTableCell123
        '
        Me.XrTableCell123.Multiline = True
        Me.XrTableCell123.Name = "XrTableCell123"
        Me.XrTableCell123.StylePriority.UseTextAlignment = False
        Me.XrTableCell123.Text = resources.GetString("XrTableCell123.Text")
        Me.XrTableCell123.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell123.Weight = 3.2408851547723208R
        '
        'XrTableCell124
        '
        Me.XrTableCell124.Multiline = True
        Me.XrTableCell124.Name = "XrTableCell124"
        Me.XrTableCell124.StylePriority.UseTextAlignment = False
        Me.XrTableCell124.Text = "5"
        Me.XrTableCell124.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell124.Weight = 0.48567737972632735R
        '
        'XrTableCell125
        '
        Me.XrTableCell125.Multiline = True
        Me.XrTableCell125.Name = "XrTableCell125"
        Me.XrTableCell125.StylePriority.UseTextAlignment = False
        Me.XrTableCell125.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell125.Weight = 0.54687461343587851R
        '
        'XrTableRow32
        '
        Me.XrTableRow32.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell126, Me.XrTableCell127, Me.XrTableCell128, Me.XrTableCell129, Me.XrTableCell130})
        Me.XrTableRow32.Name = "XrTableRow32"
        Me.XrTableRow32.Weight = 0.4426230216801712R
        '
        'XrTableCell126
        '
        Me.XrTableCell126.Multiline = True
        Me.XrTableCell126.Name = "XrTableCell126"
        Me.XrTableCell126.StylePriority.UseTextAlignment = False
        Me.XrTableCell126.Text = "XrTableCell126"
        Me.XrTableCell126.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell126.Weight = 0.35156240463256833R
        '
        'XrTableCell127
        '
        Me.XrTableCell127.Multiline = True
        Me.XrTableCell127.Name = "XrTableCell127"
        Me.XrTableCell127.StylePriority.UseTextAlignment = False
        Me.XrTableCell127.Text = "4.2"
        Me.XrTableCell127.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell127.Weight = 0.25000001827946372R
        '
        'XrTableCell128
        '
        Me.XrTableCell128.Multiline = True
        Me.XrTableCell128.Name = "XrTableCell128"
        Me.XrTableCell128.StylePriority.UseTextAlignment = False
        Me.XrTableCell128.Text = "Giao trễ   1% ~ 5% trong kỳ/.  Late delivery from 1% to 5% "
        Me.XrTableCell128.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell128.Weight = 3.2408851547723208R
        '
        'XrTableCell129
        '
        Me.XrTableCell129.Multiline = True
        Me.XrTableCell129.Name = "XrTableCell129"
        Me.XrTableCell129.StylePriority.UseTextAlignment = False
        Me.XrTableCell129.Text = "4"
        Me.XrTableCell129.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell129.Weight = 0.48567737972632735R
        '
        'XrTableCell130
        '
        Me.XrTableCell130.Multiline = True
        Me.XrTableCell130.Name = "XrTableCell130"
        Me.XrTableCell130.StylePriority.UseTextAlignment = False
        Me.XrTableCell130.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell130.Weight = 0.54687461343587851R
        '
        'XrTableRow33
        '
        Me.XrTableRow33.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell131, Me.XrTableCell132, Me.XrTableCell133, Me.XrTableCell134, Me.XrTableCell135})
        Me.XrTableRow33.Name = "XrTableRow33"
        Me.XrTableRow33.Weight = 0.4426230216801712R
        '
        'XrTableCell131
        '
        Me.XrTableCell131.Multiline = True
        Me.XrTableCell131.Name = "XrTableCell131"
        Me.XrTableCell131.StylePriority.UseTextAlignment = False
        Me.XrTableCell131.Text = "XrTableCell131"
        Me.XrTableCell131.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell131.Weight = 0.35156240463256833R
        '
        'XrTableCell132
        '
        Me.XrTableCell132.Multiline = True
        Me.XrTableCell132.Name = "XrTableCell132"
        Me.XrTableCell132.StylePriority.UseTextAlignment = False
        Me.XrTableCell132.Text = "4.3"
        Me.XrTableCell132.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell132.Weight = 0.25000001827946372R
        '
        'XrTableCell133
        '
        Me.XrTableCell133.Multiline = True
        Me.XrTableCell133.Name = "XrTableCell133"
        Me.XrTableCell133.StylePriority.UseTextAlignment = False
        Me.XrTableCell133.Text = "Giao trễ  6% ~ 10% trong kỳ/ Late delivery from 6% ~ 10 %"
        Me.XrTableCell133.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell133.Weight = 3.2408851547723208R
        '
        'XrTableCell134
        '
        Me.XrTableCell134.Multiline = True
        Me.XrTableCell134.Name = "XrTableCell134"
        Me.XrTableCell134.StylePriority.UseTextAlignment = False
        Me.XrTableCell134.Text = "3"
        Me.XrTableCell134.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell134.Weight = 0.48567737972632735R
        '
        'XrTableCell135
        '
        Me.XrTableCell135.Multiline = True
        Me.XrTableCell135.Name = "XrTableCell135"
        Me.XrTableCell135.StylePriority.UseTextAlignment = False
        Me.XrTableCell135.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell135.Weight = 0.54687461343587851R
        '
        'XrTableRow34
        '
        Me.XrTableRow34.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell136, Me.XrTableCell137, Me.XrTableCell138, Me.XrTableCell139, Me.XrTableCell140})
        Me.XrTableRow34.Name = "XrTableRow34"
        Me.XrTableRow34.Weight = 0.4426230216801712R
        '
        'XrTableCell136
        '
        Me.XrTableCell136.Multiline = True
        Me.XrTableCell136.Name = "XrTableCell136"
        Me.XrTableCell136.StylePriority.UseTextAlignment = False
        Me.XrTableCell136.Text = "XrTableCell136"
        Me.XrTableCell136.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell136.Weight = 0.35156240463256833R
        '
        'XrTableCell137
        '
        Me.XrTableCell137.Multiline = True
        Me.XrTableCell137.Name = "XrTableCell137"
        Me.XrTableCell137.StylePriority.UseTextAlignment = False
        Me.XrTableCell137.Text = "4.4"
        Me.XrTableCell137.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell137.Weight = 0.25000001827946372R
        '
        'XrTableCell138
        '
        Me.XrTableCell138.Multiline = True
        Me.XrTableCell138.Name = "XrTableCell138"
        Me.XrTableCell138.StylePriority.UseTextAlignment = False
        Me.XrTableCell138.Text = "Giao trễ 11% ~ 15% trong kỳ/ Later delivery from 11 ~ 15%"
        Me.XrTableCell138.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell138.Weight = 3.2408851547723208R
        '
        'XrTableCell139
        '
        Me.XrTableCell139.Multiline = True
        Me.XrTableCell139.Name = "XrTableCell139"
        Me.XrTableCell139.StylePriority.UseTextAlignment = False
        Me.XrTableCell139.Text = "2"
        Me.XrTableCell139.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell139.Weight = 0.48567737972632735R
        '
        'XrTableCell140
        '
        Me.XrTableCell140.Multiline = True
        Me.XrTableCell140.Name = "XrTableCell140"
        Me.XrTableCell140.StylePriority.UseTextAlignment = False
        Me.XrTableCell140.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell140.Weight = 0.54687461343587851R
        '
        'XrTableRow35
        '
        Me.XrTableRow35.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell141, Me.XrTableCell142, Me.XrTableCell143, Me.XrTableCell144, Me.XrTableCell145})
        Me.XrTableRow35.Name = "XrTableRow35"
        Me.XrTableRow35.Weight = 0.4426230216801712R
        '
        'XrTableCell141
        '
        Me.XrTableCell141.Multiline = True
        Me.XrTableCell141.Name = "XrTableCell141"
        Me.XrTableCell141.StylePriority.UseTextAlignment = False
        Me.XrTableCell141.Text = "XrTableCell141"
        Me.XrTableCell141.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell141.Weight = 0.35156240463256833R
        '
        'XrTableCell142
        '
        Me.XrTableCell142.Multiline = True
        Me.XrTableCell142.Name = "XrTableCell142"
        Me.XrTableCell142.StylePriority.UseTextAlignment = False
        Me.XrTableCell142.Text = "4.5"
        Me.XrTableCell142.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell142.Weight = 0.25000001827946372R
        '
        'XrTableCell143
        '
        Me.XrTableCell143.Multiline = True
        Me.XrTableCell143.Name = "XrTableCell143"
        Me.XrTableCell143.StylePriority.UseTextAlignment = False
        Me.XrTableCell143.Text = "Giao trễ 16% trở lên/ Later dlivery from 16% up"
        Me.XrTableCell143.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell143.Weight = 3.2408851547723208R
        '
        'XrTableCell144
        '
        Me.XrTableCell144.Multiline = True
        Me.XrTableCell144.Name = "XrTableCell144"
        Me.XrTableCell144.StylePriority.UseTextAlignment = False
        Me.XrTableCell144.Text = "1"
        Me.XrTableCell144.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell144.Weight = 0.48567737972632735R
        '
        'XrTableCell145
        '
        Me.XrTableCell145.Multiline = True
        Me.XrTableCell145.Name = "XrTableCell145"
        Me.XrTableCell145.StylePriority.UseTextAlignment = False
        Me.XrTableCell145.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell145.Weight = 0.54687461343587851R
        '
        'XrTableRow36
        '
        Me.XrTableRow36.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell146, Me.XrTableCell149, Me.XrTableCell150})
        Me.XrTableRow36.Name = "XrTableRow36"
        Me.XrTableRow36.Weight = 0.4426230216801712R
        '
        'XrTableCell146
        '
        Me.XrTableCell146.Multiline = True
        Me.XrTableCell146.Name = "XrTableCell146"
        Me.XrTableCell146.StylePriority.UseTextAlignment = False
        Me.XrTableCell146.Text = "Tổng điểm / Total mark"
        Me.XrTableCell146.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell146.Weight = 3.8424475776843527R
        '
        'XrTableCell149
        '
        Me.XrTableCell149.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell149.Multiline = True
        Me.XrTableCell149.Name = "XrTableCell149"
        Me.XrTableCell149.StylePriority.UseFont = False
        Me.XrTableCell149.StylePriority.UseTextAlignment = False
        Me.XrTableCell149.Text = "20"
        Me.XrTableCell149.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell149.Weight = 0.48567737972632735R
        '
        'XrTableCell150
        '
        Me.XrTableCell150.Multiline = True
        Me.XrTableCell150.Name = "XrTableCell150"
        Me.XrTableCell150.StylePriority.UseTextAlignment = False
        Me.XrTableCell150.Text = "para"
        Me.XrTableCell150.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell150.Weight = 0.54687461343587851R
        '
        'XrTable2
        '
        Me.XrTable2.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrTable2.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTable2.LocationFloat = New DevExpress.Utils.PointFloat(678.0!, 120.0!)
        Me.XrTable2.Name = "XrTable2"
        Me.XrTable2.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable2.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow10})
        Me.XrTable2.SizeF = New System.Drawing.SizeF(112.0!, 25.0!)
        Me.XrTable2.StylePriority.UseBorders = False
        Me.XrTable2.StylePriority.UseFont = False
        Me.XrTable2.StylePriority.UseTextAlignment = False
        Me.XrTable2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrTableRow10
        '
        Me.XrTableRow10.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell19, Me.XrTableCell20})
        Me.XrTableRow10.Name = "XrTableRow10"
        Me.XrTableRow10.Weight = 1.0R
        '
        'XrTableCell19
        '
        Me.XrTableCell19.Multiline = True
        Me.XrTableCell19.Name = "XrTableCell19"
        Me.XrTableCell19.Text = "Date:"
        Me.XrTableCell19.Weight = 0.62978754035203988R
        '
        'XrTableCell20
        '
        Me.XrTableCell20.Multiline = True
        Me.XrTableCell20.Name = "XrTableCell20"
        Me.XrTableCell20.Text = "para"
        Me.XrTableCell20.Weight = 1.2765964286389677R
        '
        'XrTable1
        '
        Me.XrTable1.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrTable1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTable1.LocationFloat = New DevExpress.Utils.PointFloat(10.0!, 120.0!)
        Me.XrTable1.Name = "XrTable1"
        Me.XrTable1.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable1.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow1, Me.XrTableRow2, Me.XrTableRow3, Me.XrTableRow4, Me.XrTableRow5, Me.XrTableRow6, Me.XrTableRow7, Me.XrTableRow8, Me.XrTableRow9})
        Me.XrTable1.SizeF = New System.Drawing.SizeF(651.0416!, 184.375!)
        Me.XrTable1.StylePriority.UseBorders = False
        Me.XrTable1.StylePriority.UseFont = False
        Me.XrTable1.StylePriority.UseTextAlignment = False
        Me.XrTable1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrTableRow1
        '
        Me.XrTableRow1.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell1, Me.XrTableCell2})
        Me.XrTableRow1.Name = "XrTableRow1"
        Me.XrTableRow1.Weight = 1.0R
        '
        'XrTableCell1
        '
        Me.XrTableCell1.Multiline = True
        Me.XrTableCell1.Name = "XrTableCell1"
        Me.XrTableCell1.Text = "Tên nhà cung cấp/ Vender name: "
        Me.XrTableCell1.Weight = 2.145051472855974R
        '
        'XrTableCell2
        '
        Me.XrTableCell2.Multiline = True
        Me.XrTableCell2.Name = "XrTableCell2"
        Me.XrTableCell2.Text = "para"
        Me.XrTableCell2.Weight = 3.7336811066533868R
        '
        'XrTableRow2
        '
        Me.XrTableRow2.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell4, Me.XrTableCell5})
        Me.XrTableRow2.Name = "XrTableRow2"
        Me.XrTableRow2.Weight = 1.0R
        '
        'XrTableCell4
        '
        Me.XrTableCell4.Multiline = True
        Me.XrTableCell4.Name = "XrTableCell4"
        Me.XrTableCell4.Text = "Người liên hệ/ Contact person:"
        Me.XrTableCell4.Weight = 2.145051472855974R
        '
        'XrTableCell5
        '
        Me.XrTableCell5.Multiline = True
        Me.XrTableCell5.Name = "XrTableCell5"
        Me.XrTableCell5.Text = "para"
        Me.XrTableCell5.Weight = 3.7336811066533868R
        '
        'XrTableRow3
        '
        Me.XrTableRow3.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell7, Me.XrTableCell8})
        Me.XrTableRow3.Name = "XrTableRow3"
        Me.XrTableRow3.Weight = 1.0R
        '
        'XrTableCell7
        '
        Me.XrTableCell7.Multiline = True
        Me.XrTableCell7.Name = "XrTableCell7"
        Me.XrTableCell7.Text = "Địa chỉ /Address:"
        Me.XrTableCell7.Weight = 2.145051472855974R
        '
        'XrTableCell8
        '
        Me.XrTableCell8.Multiline = True
        Me.XrTableCell8.Name = "XrTableCell8"
        Me.XrTableCell8.Text = "para"
        Me.XrTableCell8.Weight = 3.7336811066533868R
        '
        'XrTableRow4
        '
        Me.XrTableRow4.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell3, Me.XrTableCell6})
        Me.XrTableRow4.Name = "XrTableRow4"
        Me.XrTableRow4.Weight = 1.0R
        '
        'XrTableCell3
        '
        Me.XrTableCell3.Multiline = True
        Me.XrTableCell3.Name = "XrTableCell3"
        Me.XrTableCell3.Text = "Tel/Fax:"
        Me.XrTableCell3.Weight = 2.145051472855974R
        '
        'XrTableCell6
        '
        Me.XrTableCell6.Multiline = True
        Me.XrTableCell6.Name = "XrTableCell6"
        Me.XrTableCell6.Text = "para"
        Me.XrTableCell6.Weight = 3.7336811066533868R
        '
        'XrTableRow5
        '
        Me.XrTableRow5.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell9, Me.XrTableCell10})
        Me.XrTableRow5.Name = "XrTableRow5"
        Me.XrTableRow5.Weight = 1.0R
        '
        'XrTableCell9
        '
        Me.XrTableCell9.Multiline = True
        Me.XrTableCell9.Name = "XrTableCell9"
        Me.XrTableCell9.Text = "Sản phẩm/dịch vụ / Products/Services:"
        Me.XrTableCell9.Weight = 2.145051472855974R
        '
        'XrTableCell10
        '
        Me.XrTableCell10.Multiline = True
        Me.XrTableCell10.Name = "XrTableCell10"
        Me.XrTableCell10.Text = "para"
        Me.XrTableCell10.Weight = 3.7336811066533868R
        '
        'XrTableRow6
        '
        Me.XrTableRow6.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell11, Me.XrTableCell12})
        Me.XrTableRow6.Name = "XrTableRow6"
        Me.XrTableRow6.Weight = 1.0R
        '
        'XrTableCell11
        '
        Me.XrTableCell11.Multiline = True
        Me.XrTableCell11.Name = "XrTableCell11"
        Me.XrTableCell11.Text = "Căn cứ đánh giá/ base use for evaluation:"
        Me.XrTableCell11.Weight = 2.145051472855974R
        '
        'XrTableCell12
        '
        Me.XrTableCell12.Multiline = True
        Me.XrTableCell12.Name = "XrTableCell12"
        Me.XrTableCell12.Text = "PO TAPE"
        Me.XrTableCell12.Weight = 3.7336811066533868R
        '
        'XrTableRow7
        '
        Me.XrTableRow7.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell13, Me.XrTableCell14})
        Me.XrTableRow7.Name = "XrTableRow7"
        Me.XrTableRow7.Weight = 1.0R
        '
        'XrTableCell13
        '
        Me.XrTableCell13.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrTableCell13.Multiline = True
        Me.XrTableCell13.Name = "XrTableCell13"
        Me.XrTableCell13.StylePriority.UseBorders = False
        Me.XrTableCell13.Weight = 2.145051472855974R
        '
        'XrTableCell14
        '
        Me.XrTableCell14.Multiline = True
        Me.XrTableCell14.Name = "XrTableCell14"
        Me.XrTableCell14.Text = "ARIBA INVOICE LIST"
        Me.XrTableCell14.Weight = 3.7336811066533868R
        '
        'XrTableRow8
        '
        Me.XrTableRow8.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell15, Me.XrTableCell16})
        Me.XrTableRow8.Name = "XrTableRow8"
        Me.XrTableRow8.Weight = 1.0R
        '
        'XrTableCell15
        '
        Me.XrTableCell15.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrTableCell15.Multiline = True
        Me.XrTableCell15.Name = "XrTableCell15"
        Me.XrTableCell15.StylePriority.UseBorders = False
        Me.XrTableCell15.Weight = 2.145051472855974R
        '
        'XrTableCell16
        '
        Me.XrTableCell16.Multiline = True
        Me.XrTableCell16.Name = "XrTableCell16"
        Me.XrTableCell16.Text = "Non- Conformities reports."
        Me.XrTableCell16.Weight = 3.7336811066533868R
        '
        'XrTableRow9
        '
        Me.XrTableRow9.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell17, Me.XrTableCell18})
        Me.XrTableRow9.Name = "XrTableRow9"
        Me.XrTableRow9.Weight = 1.0R
        '
        'XrTableCell17
        '
        Me.XrTableCell17.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrTableCell17.Multiline = True
        Me.XrTableCell17.Name = "XrTableCell17"
        Me.XrTableCell17.StylePriority.UseBorders = False
        Me.XrTableCell17.Weight = 2.145051472855974R
        '
        'XrTableCell18
        '
        Me.XrTableCell18.Multiline = True
        Me.XrTableCell18.Name = "XrTableCell18"
        Me.XrTableCell18.Text = "Price compasion."
        Me.XrTableCell18.Weight = 3.7336811066533868R
        '
        'XrLabel6
        '
        Me.XrLabel6.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel6.Font = New System.Drawing.Font("Times New Roman", 15.0!, System.Drawing.FontStyle.Bold)
        Me.XrLabel6.LocationFloat = New DevExpress.Utils.PointFloat(461.58!, 90.0!)
        Me.XrLabel6.Multiline = True
        Me.XrLabel6.Name = "XrLabel6"
        Me.XrLabel6.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel6.SizeF = New System.Drawing.SizeF(84.375!, 22.99999!)
        Me.XrLabel6.StylePriority.UseBorders = False
        Me.XrLabel6.StylePriority.UseFont = False
        Me.XrLabel6.Text = "PARA"
        '
        'XrLabel5
        '
        Me.XrLabel5.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel5.Font = New System.Drawing.Font("Times New Roman", 15.0!, System.Drawing.FontStyle.Bold)
        Me.XrLabel5.LocationFloat = New DevExpress.Utils.PointFloat(322.37!, 90.0!)
        Me.XrLabel5.Multiline = True
        Me.XrLabel5.Name = "XrLabel5"
        Me.XrLabel5.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel5.SizeF = New System.Drawing.SizeF(139.2083!, 22.99999!)
        Me.XrLabel5.StylePriority.UseBorders = False
        Me.XrLabel5.StylePriority.UseFont = False
        Me.XrLabel5.Text = "NĂM / YEAR:"
        '
        'XrLabel4
        '
        Me.XrLabel4.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel4.Font = New System.Drawing.Font("Times New Roman", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel4.LocationFloat = New DevExpress.Utils.PointFloat(287.9998!, 60.0!)
        Me.XrLabel4.Multiline = True
        Me.XrLabel4.Name = "XrLabel4"
        Me.XrLabel4.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel4.SizeF = New System.Drawing.SizeF(184.0!, 23.0!)
        Me.XrLabel4.StylePriority.UseBorders = False
        Me.XrLabel4.StylePriority.UseFont = False
        Me.XrLabel4.StylePriority.UseTextAlignment = False
        Me.XrLabel4.Text = "VENDER REVIEW"
        Me.XrLabel4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrLabel3
        '
        Me.XrLabel3.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel3.Font = New System.Drawing.Font("Times New Roman", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel3.ForeColor = System.Drawing.Color.Red
        Me.XrLabel3.LocationFloat = New DevExpress.Utils.PointFloat(471.9999!, 60.0!)
        Me.XrLabel3.Multiline = True
        Me.XrLabel3.Name = "XrLabel3"
        Me.XrLabel3.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel3.SizeF = New System.Drawing.SizeF(100.0!, 23.0!)
        Me.XrLabel3.StylePriority.UseBorders = False
        Me.XrLabel3.StylePriority.UseFont = False
        Me.XrLabel3.StylePriority.UseForeColor = False
        Me.XrLabel3.StylePriority.UseTextAlignment = False
        Me.XrLabel3.Text = "SHEET"
        Me.XrLabel3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrLabel2
        '
        Me.XrLabel2.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel2.Font = New System.Drawing.Font("Times New Roman", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel2.LocationFloat = New DevExpress.Utils.PointFloat(228.62!, 35.0!)
        Me.XrLabel2.Multiline = True
        Me.XrLabel2.Name = "XrLabel2"
        Me.XrLabel2.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel2.SizeF = New System.Drawing.SizeF(396.88!, 25.0!)
        Me.XrLabel2.StylePriority.UseBorders = False
        Me.XrLabel2.StylePriority.UseFont = False
        Me.XrLabel2.StylePriority.UseTextAlignment = False
        Me.XrLabel2.Text = "BẢNG ĐÁNH GIÁ LẠI NHÀ CUNG CẤP"
        Me.XrLabel2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        '
        'XrLabel1
        '
        Me.XrLabel1.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrLabel1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel1.ForeColor = System.Drawing.Color.Blue
        Me.XrLabel1.LocationFloat = New DevExpress.Utils.PointFloat(195.2916!, 10.00001!)
        Me.XrLabel1.Multiline = True
        Me.XrLabel1.Name = "XrLabel1"
        Me.XrLabel1.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel1.SizeF = New System.Drawing.SizeF(430.2083!, 20.83333!)
        Me.XrLabel1.StylePriority.UseBorders = False
        Me.XrLabel1.StylePriority.UseFont = False
        Me.XrLabel1.StylePriority.UseForeColor = False
        Me.XrLabel1.StylePriority.UseTextAlignment = False
        Me.XrLabel1.Text = "Nitto Denko Tape Materials (Vietnam) Co., Ltd."
        Me.XrLabel1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        '
        'XrPictureBox1
        '
        Me.XrPictureBox1.Borders = DevExpress.XtraPrinting.BorderSide.None
        Me.XrPictureBox1.ImageSource = New DevExpress.XtraPrinting.Drawing.ImageSource("img", resources.GetString("XrPictureBox1.ImageSource"))
        Me.XrPictureBox1.LocationFloat = New DevExpress.Utils.PointFloat(76.54!, 5.0!)
        Me.XrPictureBox1.Name = "XrPictureBox1"
        Me.XrPictureBox1.SizeF = New System.Drawing.SizeF(85.41666!, 31.25!)
        Me.XrPictureBox1.StylePriority.UseBorders = False
        '
        'ReportFooter
        '
        Me.ReportFooter.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrTable7, Me.XrTable5})
        Me.ReportFooter.HeightF = 271.0417!
        Me.ReportFooter.Name = "ReportFooter"
        '
        'XrTable5
        '
        Me.XrTable5.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 9.999974!)
        Me.XrTable5.Name = "XrTable5"
        Me.XrTable5.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable5.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow39, Me.XrTableRow40, Me.XrTableRow41, Me.XrTableRow42, Me.XrTableRow43, Me.XrTableRow44, Me.XrTableRow46, Me.XrTableRow45})
        Me.XrTable5.SizeF = New System.Drawing.SizeF(779.9999!, 160.0!)
        Me.XrTable5.StylePriority.UseTextAlignment = False
        Me.XrTable5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        '
        'XrTableRow39
        '
        Me.XrTableRow39.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell155, Me.XrTableCell156, Me.XrTableCell157, Me.XrTableCell158})
        Me.XrTableRow39.Name = "XrTableRow39"
        Me.XrTableRow39.Weight = 0.8R
        '
        'XrTableCell155
        '
        Me.XrTableCell155.Font = New System.Drawing.Font("Times New Roman", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell155.Multiline = True
        Me.XrTableCell155.Name = "XrTableCell155"
        Me.XrTableCell155.StylePriority.UseFont = False
        Me.XrTableCell155.StylePriority.UseTextAlignment = False
        Me.XrTableCell155.Text = "Kết luận:"
        Me.XrTableCell155.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell155.Weight = 1.0R
        '
        'XrTableCell156
        '
        Me.XrTableCell156.Multiline = True
        Me.XrTableCell156.Name = "XrTableCell156"
        Me.XrTableCell156.Weight = 1.0R
        '
        'XrTableCell157
        '
        Me.XrTableCell157.Multiline = True
        Me.XrTableCell157.Name = "XrTableCell157"
        Me.XrTableCell157.Weight = 1.0R
        '
        'XrTableCell158
        '
        Me.XrTableCell158.Multiline = True
        Me.XrTableCell158.Name = "XrTableCell158"
        Me.XrTableCell158.Weight = 1.0R
        '
        'XrTableRow40
        '
        Me.XrTableRow40.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell159, Me.XrTableCell160, Me.XrTableCell180})
        Me.XrTableRow40.Name = "XrTableRow40"
        Me.XrTableRow40.Weight = 0.8R
        '
        'XrTableCell159
        '
        Me.XrTableCell159.Font = New System.Drawing.Font("Times New Roman", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell159.Multiline = True
        Me.XrTableCell159.Name = "XrTableCell159"
        Me.XrTableCell159.StylePriority.UseFont = False
        Me.XrTableCell159.StylePriority.UseTextAlignment = False
        Me.XrTableCell159.Text = "Conclusion: "
        Me.XrTableCell159.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell159.Weight = 1.0R
        '
        'XrTableCell160
        '
        Me.XrTableCell160.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrRichText1})
        Me.XrTableCell160.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell160.Multiline = True
        Me.XrTableCell160.Name = "XrTableCell160"
        Me.XrTableCell160.StylePriority.UseFont = False
        Me.XrTableCell160.StylePriority.UseTextAlignment = False
        Me.XrTableCell160.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell160.Weight = 0.10256411861542816R
        '
        'XrTableRow41
        '
        Me.XrTableRow41.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell163, Me.XrTableCell164, Me.XrTableCell181})
        Me.XrTableRow41.Name = "XrTableRow41"
        Me.XrTableRow41.Weight = 0.8R
        '
        'XrTableCell163
        '
        Me.XrTableCell163.Font = New System.Drawing.Font("Times New Roman", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell163.Multiline = True
        Me.XrTableCell163.Name = "XrTableCell163"
        Me.XrTableCell163.StylePriority.UseFont = False
        Me.XrTableCell163.StylePriority.UseTextAlignment = False
        Me.XrTableCell163.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell163.Weight = 1.0R
        '
        'XrTableCell164
        '
        Me.XrTableCell164.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrRichText2})
        Me.XrTableCell164.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell164.Multiline = True
        Me.XrTableCell164.Name = "XrTableCell164"
        Me.XrTableCell164.StylePriority.UseFont = False
        Me.XrTableCell164.StylePriority.UseTextAlignment = False
        Me.XrTableCell164.Text = "o Không chấp nhận/ Reject"
        Me.XrTableCell164.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell164.Weight = 0.10256411861542825R
        '
        'XrTableRow42
        '
        Me.XrTableRow42.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell167, Me.XrTableCell168, Me.XrTableCell182})
        Me.XrTableRow42.Name = "XrTableRow42"
        Me.XrTableRow42.Weight = 0.8R
        '
        'XrTableCell167
        '
        Me.XrTableCell167.Font = New System.Drawing.Font("Times New Roman", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell167.Multiline = True
        Me.XrTableCell167.Name = "XrTableCell167"
        Me.XrTableCell167.StylePriority.UseFont = False
        Me.XrTableCell167.StylePriority.UseTextAlignment = False
        Me.XrTableCell167.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell167.Weight = 1.0R
        '
        'XrTableCell168
        '
        Me.XrTableCell168.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrRichText3})
        Me.XrTableCell168.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell168.Multiline = True
        Me.XrTableCell168.Name = "XrTableCell168"
        Me.XrTableCell168.StylePriority.UseFont = False
        Me.XrTableCell168.StylePriority.UseTextAlignment = False
        Me.XrTableCell168.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell168.Weight = 0.10256411861542815R
        '
        'XrTableRow43
        '
        Me.XrTableRow43.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell161})
        Me.XrTableRow43.Name = "XrTableRow43"
        Me.XrTableRow43.Weight = 0.8R
        '
        'XrTableCell161
        '
        Me.XrTableCell161.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell161.Multiline = True
        Me.XrTableCell161.Name = "XrTableCell161"
        Me.XrTableCell161.StylePriority.UseFont = False
        Me.XrTableCell161.StylePriority.UseTextAlignment = False
        Me.XrTableCell161.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell161.Weight = 4.0R
        '
        'XrTableRow44
        '
        Me.XrTableRow44.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell162})
        Me.XrTableRow44.Name = "XrTableRow44"
        Me.XrTableRow44.Weight = 0.8R
        '
        'XrTableCell162
        '
        Me.XrTableCell162.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell162.Multiline = True
        Me.XrTableCell162.Name = "XrTableCell162"
        Me.XrTableCell162.StylePriority.UseFont = False
        Me.XrTableCell162.StylePriority.UseTextAlignment = False
        Me.XrTableCell162.Text = "* Đối với các dịch vụ thuê ngoài bộ phận QA không xác nhận vào form này/ For out " &
    "sourcing supply, QA dept not varified in this form."
        Me.XrTableCell162.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell162.Weight = 4.0R
        '
        'XrTableRow46
        '
        Me.XrTableRow46.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell171})
        Me.XrTableRow46.Name = "XrTableRow46"
        Me.XrTableRow46.Weight = 0.8R
        '
        'XrTableCell171
        '
        Me.XrTableCell171.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell171.Multiline = True
        Me.XrTableCell171.Name = "XrTableCell171"
        Me.XrTableCell171.StylePriority.UseFont = False
        Me.XrTableCell171.StylePriority.UseTextAlignment = False
        Me.XrTableCell171.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell171.Weight = 4.0R
        '
        'XrTableRow45
        '
        Me.XrTableRow45.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell165, Me.XrTableCell166, Me.XrTableCell169, Me.XrTableCell170})
        Me.XrTableRow45.Name = "XrTableRow45"
        Me.XrTableRow45.Weight = 0.8R
        '
        'XrTableCell165
        '
        Me.XrTableCell165.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell165.Multiline = True
        Me.XrTableCell165.Name = "XrTableCell165"
        Me.XrTableCell165.Padding = New DevExpress.XtraPrinting.PaddingInfo(10, 10, 0, 0, 100.0!)
        Me.XrTableCell165.StylePriority.UseFont = False
        Me.XrTableCell165.StylePriority.UsePadding = False
        Me.XrTableCell165.StylePriority.UseTextAlignment = False
        Me.XrTableCell165.Text = "Đánh giá bởi BP phụ trách mua hàng/ Dept in charge "
        Me.XrTableCell165.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell165.Weight = 0.92948724670210559R
        '
        'XrTableCell166
        '
        Me.XrTableCell166.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell166.Multiline = True
        Me.XrTableCell166.Name = "XrTableCell166"
        Me.XrTableCell166.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrTableCell166.StylePriority.UseFont = False
        Me.XrTableCell166.StylePriority.UsePadding = False
        Me.XrTableCell166.StylePriority.UseTextAlignment = False
        Me.XrTableCell166.Text = "QA kiểm tra/QA checker HOD/ Designated"
        Me.XrTableCell166.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell166.Weight = 1.0705130662987445R
        '
        'XrTableCell169
        '
        Me.XrTableCell169.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell169.Multiline = True
        Me.XrTableCell169.Name = "XrTableCell169"
        Me.XrTableCell169.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrTableCell169.StylePriority.UseFont = False
        Me.XrTableCell169.StylePriority.UsePadding = False
        Me.XrTableCell169.StylePriority.UseTextAlignment = False
        Me.XrTableCell169.Text = "TGĐ duyệt/Approver Gernenal Director"
        Me.XrTableCell169.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell169.Weight = 1.0976492227641137R
        '
        'XrTableCell170
        '
        Me.XrTableCell170.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTableCell170.Multiline = True
        Me.XrTableCell170.Name = "XrTableCell170"
        Me.XrTableCell170.StylePriority.UseFont = False
        Me.XrTableCell170.StylePriority.UseTextAlignment = False
        Me.XrTableCell170.Text = "NCC xác nhận" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Vender confirmation"
        Me.XrTableCell170.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter
        Me.XrTableCell170.Weight = 0.90235046423503606R
        '
        'Detail
        '
        Me.Detail.HeightF = 0!
        Me.Detail.Name = "Detail"
        '
        'XrTable6
        '
        Me.XrTable6.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrTable6.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 0!)
        Me.XrTable6.Name = "XrTable6"
        Me.XrTable6.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable6.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow47})
        Me.XrTable6.SizeF = New System.Drawing.SizeF(779.9999!, 37.0!)
        Me.XrTable6.StylePriority.UseFont = False
        '
        'XrTableRow47
        '
        Me.XrTableRow47.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell172, Me.XrTableCell175, Me.XrTableCell173, Me.XrTableCell174})
        Me.XrTableRow47.Name = "XrTableRow47"
        Me.XrTableRow47.Weight = 1.48R
        '
        'XrTableCell172
        '
        Me.XrTableCell172.Multiline = True
        Me.XrTableCell172.Name = "XrTableCell172"
        Me.XrTableCell172.StylePriority.UseTextAlignment = False
        Me.XrTableCell172.Text = "Page:"
        Me.XrTableCell172.TextAlignment = DevExpress.XtraPrinting.TextAlignment.BottomLeft
        Me.XrTableCell172.Weight = 0.35R
        '
        'XrTableCell173
        '
        Me.XrTableCell173.Multiline = True
        Me.XrTableCell173.Name = "XrTableCell173"
        Me.XrTableCell173.StylePriority.UseTextAlignment = False
        Me.XrTableCell173.Text = "B-g V-0802 WI-01 F03      Date: 03/Aug/2020"
        Me.XrTableCell173.TextAlignment = DevExpress.XtraPrinting.TextAlignment.BottomCenter
        Me.XrTableCell173.Weight = 3.5483148193359373R
        '
        'XrTableCell174
        '
        Me.XrTableCell174.Multiline = True
        Me.XrTableCell174.Name = "XrTableCell174"
        Me.XrTableCell174.StylePriority.UseTextAlignment = False
        Me.XrTableCell174.Text = "REV: 006" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Thời gian lưu / saving duration: 2 năm / 2 years"
        Me.XrTableCell174.TextAlignment = DevExpress.XtraPrinting.TextAlignment.BottomRight
        Me.XrTableCell174.Weight = 2.7321166992187496R
        '
        'XrTableCell175
        '
        Me.XrTableCell175.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrPageInfo1})
        Me.XrTableCell175.ExpressionBindings.AddRange(New DevExpress.XtraReports.UI.ExpressionBinding() {New DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", ""), New DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", ""), New DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "")})
        Me.XrTableCell175.Multiline = True
        Me.XrTableCell175.Name = "XrTableCell175"
        Me.XrTableCell175.StylePriority.UseTextAlignment = False
        Me.XrTableCell175.TextAlignment = DevExpress.XtraPrinting.TextAlignment.BottomLeft
        Me.XrTableCell175.Weight = 1.1695672607421876R
        '
        'XrPageInfo1
        '
        Me.XrPageInfo1.LocationFloat = New DevExpress.Utils.PointFloat(0!, 0!)
        Me.XrPageInfo1.Name = "XrPageInfo1"
        Me.XrPageInfo1.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrPageInfo1.PageInfo = DevExpress.XtraPrinting.PageInfo.Number
        Me.XrPageInfo1.SizeF = New System.Drawing.SizeF(116.9567!, 37.00002!)
        '
        'XrTable7
        '
        Me.XrTable7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTable7.LocationFloat = New DevExpress.Utils.PointFloat(10.0!, 240.0!)
        Me.XrTable7.Name = "XrTable7"
        Me.XrTable7.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96.0!)
        Me.XrTable7.Rows.AddRange(New DevExpress.XtraReports.UI.XRTableRow() {Me.XrTableRow48})
        Me.XrTable7.SizeF = New System.Drawing.SizeF(780.0!, 25.0!)
        Me.XrTable7.StylePriority.UseFont = False
        '
        'XrTableRow48
        '
        Me.XrTableRow48.Cells.AddRange(New DevExpress.XtraReports.UI.XRTableCell() {Me.XrTableCell176, Me.XrTableCell179, Me.XrTableCell177, Me.XrTableCell178})
        Me.XrTableRow48.Name = "XrTableRow48"
        Me.XrTableRow48.Weight = 1.0R
        '
        'XrTableCell176
        '
        Me.XrTableCell176.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold)
        Me.XrTableCell176.Multiline = True
        Me.XrTableCell176.Name = "XrTableCell176"
        Me.XrTableCell176.StylePriority.UseFont = False
        Me.XrTableCell176.StylePriority.UseTextAlignment = False
        Me.XrTableCell176.Text = "__________________"
        Me.XrTableCell176.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter
        Me.XrTableCell176.Weight = 0.6971153259277344R
        '
        'XrTableCell177
        '
        Me.XrTableCell177.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrTableCell177.Multiline = True
        Me.XrTableCell177.Name = "XrTableCell177"
        Me.XrTableCell177.StylePriority.UseFont = False
        Me.XrTableCell177.StylePriority.UseTextAlignment = False
        Me.XrTableCell177.Text = "_________________________"
        Me.XrTableCell177.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter
        Me.XrTableCell177.Weight = 0.82323702298677892R
        '
        'XrTableCell178
        '
        Me.XrTableCell178.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrTableCell178.Multiline = True
        Me.XrTableCell178.Name = "XrTableCell178"
        Me.XrTableCell178.StylePriority.UseFont = False
        Me.XrTableCell178.StylePriority.UseTextAlignment = False
        Me.XrTableCell178.Text = "___________________"
        Me.XrTableCell178.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter
        Me.XrTableCell178.Weight = 0.67676297701322108R
        '
        'XrTableCell179
        '
        Me.XrTableCell179.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrTableCell179.Multiline = True
        Me.XrTableCell179.Name = "XrTableCell179"
        Me.XrTableCell179.StylePriority.UseFont = False
        Me.XrTableCell179.StylePriority.UseTextAlignment = False
        Me.XrTableCell179.Text = "______________________"
        Me.XrTableCell179.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter
        Me.XrTableCell179.Weight = 0.8028846740722656R
        '
        'XrRichText1
        '
        Me.XrRichText1.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrRichText1.LocationFloat = New DevExpress.Utils.PointFloat(0.00001525879!, 3.0!)
        Me.XrRichText1.Name = "XrRichText1"
        Me.XrRichText1.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrRichText1.SerializableRtfString = resources.GetString("XrRichText1.SerializableRtfString")
        Me.XrRichText1.SizeF = New System.Drawing.SizeF(20.0!, 17.0!)
        '
        'XrTableCell180
        '
        Me.XrTableCell180.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell180.Multiline = True
        Me.XrTableCell180.Name = "XrTableCell180"
        Me.XrTableCell180.StylePriority.UseFont = False
        Me.XrTableCell180.StylePriority.UseTextAlignment = False
        Me.XrTableCell180.Text = "Chấp nhận / Aprroved"
        Me.XrTableCell180.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell180.Weight = 2.8974358813845718R
        '
        'XrTableCell181
        '
        Me.XrTableCell181.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell181.Multiline = True
        Me.XrTableCell181.Name = "XrTableCell181"
        Me.XrTableCell181.StylePriority.UseFont = False
        Me.XrTableCell181.StylePriority.UseTextAlignment = False
        Me.XrTableCell181.Text = "Không chấp nhận/ Reject"
        Me.XrTableCell181.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell181.Weight = 2.8974358813845718R
        '
        'XrRichText2
        '
        Me.XrRichText2.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrRichText2.LocationFloat = New DevExpress.Utils.PointFloat(0.00001525879!, 2.999996!)
        Me.XrRichText2.Name = "XrRichText2"
        Me.XrRichText2.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrRichText2.SerializableRtfString = resources.GetString("XrRichText2.SerializableRtfString")
        Me.XrRichText2.SizeF = New System.Drawing.SizeF(20.0!, 17.0!)
        '
        'XrTableCell182
        '
        Me.XrTableCell182.Font = New System.Drawing.Font("Times New Roman", 9.75!)
        Me.XrTableCell182.Multiline = True
        Me.XrTableCell182.Name = "XrTableCell182"
        Me.XrTableCell182.StylePriority.UseFont = False
        Me.XrTableCell182.StylePriority.UseTextAlignment = False
        Me.XrTableCell182.Text = "Ý kiến khác ghi chi tiết/ Other commentwrite in detial___________________________" &
    "_______"
        Me.XrTableCell182.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft
        Me.XrTableCell182.Weight = 2.8974358813845713R
        '
        'XrRichText3
        '
        Me.XrRichText3.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.XrRichText3.LocationFloat = New DevExpress.Utils.PointFloat(0.00001525879!, 3.000004!)
        Me.XrRichText3.Name = "XrRichText3"
        Me.XrRichText3.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrRichText3.SerializableRtfString = resources.GetString("XrRichText3.SerializableRtfString")
        Me.XrRichText3.SizeF = New System.Drawing.SizeF(20.0!, 17.0!)
        '
        'VenderReview
        '
        Me.Bands.AddRange(New DevExpress.XtraReports.UI.Band() {Me.TopMargin, Me.BottomMargin, Me.ReportHeader, Me.ReportFooter, Me.Detail})
        Me.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.Margins = New System.Drawing.Printing.Margins(12, 15, 10, 43)
        Me.PageHeight = 1169
        Me.PageWidth = 827
        Me.PaperKind = System.Drawing.Printing.PaperKind.A4
        Me.Version = "20.1"
        CType(Me.XrTable4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrTable7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrRichText1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrRichText2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.XrRichText3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Friend WithEvents TopMargin As DevExpress.XtraReports.UI.TopMarginBand
    Friend WithEvents BottomMargin As DevExpress.XtraReports.UI.BottomMarginBand
    Friend WithEvents ReportHeader As DevExpress.XtraReports.UI.ReportHeaderBand
    Friend WithEvents ReportFooter As DevExpress.XtraReports.UI.ReportFooterBand
    Friend WithEvents Detail As DevExpress.XtraReports.UI.DetailBand
    Friend WithEvents XrPictureBox1 As DevExpress.XtraReports.UI.XRPictureBox
    Friend WithEvents XrLabel1 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel3 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel2 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel4 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel5 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel6 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrTable1 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow1 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell1 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell2 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow2 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell4 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell5 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow3 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell7 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell8 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow4 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell3 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell6 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow5 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell9 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell10 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow6 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell11 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell12 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow7 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell13 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell14 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow8 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell15 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell16 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow9 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell17 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell18 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTable2 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow10 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell19 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell20 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTable3 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow11 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell21 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell22 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell23 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell24 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell25 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow12 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell26 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell27 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell28 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell29 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell30 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow13 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell31 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell32 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell33 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell34 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell35 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow14 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell36 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell37 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell38 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell39 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell40 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow15 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell41 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell42 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell43 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell44 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell45 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow16 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell46 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell47 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell48 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell49 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell50 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow17 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell51 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell52 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell53 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell54 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell55 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow18 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell56 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell57 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell58 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell59 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell60 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow19 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell61 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell62 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell63 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell64 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell65 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow20 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell66 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell67 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell68 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell69 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell70 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow21 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell71 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell72 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell73 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell74 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell75 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow22 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell76 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell77 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell78 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell79 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell80 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow23 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell81 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell82 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell83 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell84 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell85 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow24 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell86 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell87 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell88 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell89 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell90 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow25 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell91 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell92 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell93 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell94 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell95 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow26 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell96 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell97 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell98 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell99 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell100 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow27 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell101 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell102 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell103 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell104 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell105 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow28 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell106 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell107 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell108 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell109 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell110 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow29 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell111 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell112 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell113 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell114 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell115 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow30 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell116 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell117 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell118 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell119 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell120 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow31 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell121 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell122 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell123 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell124 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell125 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow32 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell126 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell127 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell128 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell129 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell130 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow33 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell131 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell132 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell133 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell134 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell135 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow34 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell136 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell137 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell138 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell139 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell140 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow35 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell141 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell142 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell143 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell144 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell145 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow36 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell146 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell149 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell150 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTable4 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow37 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell147 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell148 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell151 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow38 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell152 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell153 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell154 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTable5 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow39 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell155 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell156 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell157 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell158 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow40 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell159 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell160 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow41 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell163 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell164 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow42 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell167 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell168 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow43 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell161 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow44 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell162 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow45 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell165 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell166 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell169 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell170 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableRow46 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell171 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTable6 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow47 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell172 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell173 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell174 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell175 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrPageInfo1 As DevExpress.XtraReports.UI.XRPageInfo
    Friend WithEvents XrTable7 As DevExpress.XtraReports.UI.XRTable
    Friend WithEvents XrTableRow48 As DevExpress.XtraReports.UI.XRTableRow
    Friend WithEvents XrTableCell176 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell179 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell177 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrTableCell178 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrRichText1 As DevExpress.XtraReports.UI.XRRichText
    Friend WithEvents XrTableCell180 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrRichText2 As DevExpress.XtraReports.UI.XRRichText
    Friend WithEvents XrTableCell181 As DevExpress.XtraReports.UI.XRTableCell
    Friend WithEvents XrRichText3 As DevExpress.XtraReports.UI.XRRichText
    Friend WithEvents XrTableCell182 As DevExpress.XtraReports.UI.XRTableCell
End Class
